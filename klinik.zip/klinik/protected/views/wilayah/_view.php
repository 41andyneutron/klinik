<?php
/* @var $this WilayahController */
/* @var $data Wilayah */
?>

<div class="view">

	<b><?php echo CHtml::encode($data->getAttributeLabel('id_wilayah')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->id_wilayah), array('view', 'id'=>$data->id_wilayah)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('id_prov')); ?>:</b>
	<?php echo CHtml::encode($data->id_prov); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('nama_kab_kota')); ?>:</b>
	<?php echo CHtml::encode($data->nama_kab_kota); ?>
	<br />


</div>