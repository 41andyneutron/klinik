<?php
/* @var $this ProvController */
/* @var $model Prov */

$this->breadcrumbs=array(
	'Provs'=>array('index'),
	'Create',
);

$this->menu=array(
	array('label'=>'List Prov', 'url'=>array('index')),
	array('label'=>'Manage Prov', 'url'=>array('admin')),
);
?>

<h1>Create Prov</h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>