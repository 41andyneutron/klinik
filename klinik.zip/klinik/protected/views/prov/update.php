<?php
/* @var $this ProvController */
/* @var $model Prov */

$this->breadcrumbs=array(
	'Provs'=>array('index'),
	$model->id_prov=>array('view','id'=>$model->id_prov),
	'Update',
);

$this->menu=array(
	array('label'=>'List Prov', 'url'=>array('index')),
	array('label'=>'Create Prov', 'url'=>array('create')),
	array('label'=>'View Prov', 'url'=>array('view', 'id'=>$model->id_prov)),
	array('label'=>'Manage Prov', 'url'=>array('admin')),
);
?>

<h1>Update Prov <?php echo $model->id_prov; ?></h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>