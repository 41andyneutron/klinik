<?php
/* @var $this ProvController */
/* @var $model Prov */

$this->breadcrumbs=array(
	'Provs'=>array('index'),
	$model->id_prov,
);

$this->menu=array(
	array('label'=>'List Prov', 'url'=>array('index')),
	array('label'=>'Create Prov', 'url'=>array('create')),
	array('label'=>'Update Prov', 'url'=>array('update', 'id'=>$model->id_prov)),
	array('label'=>'Delete Prov', 'url'=>'#', 'linkOptions'=>array('submit'=>array('delete','id'=>$model->id_prov),'confirm'=>'Are you sure you want to delete this item?')),
	array('label'=>'Manage Prov', 'url'=>array('admin')),
);
?>

<h1>View Prov #<?php echo $model->id_prov; ?></h1>

<?php $this->widget('zii.widgets.CDetailView', array(
	'data'=>$model,
	'attributes'=>array(
		'id_prov',
		'nama_prov',
	),
)); ?>
