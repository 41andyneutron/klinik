<?php
/* @var $this ProvController */
/* @var $dataProvider CActiveDataProvider */

$this->breadcrumbs=array(
	'Provs',
);

$this->menu=array(
	array('label'=>'Create Prov', 'url'=>array('create')),
	array('label'=>'Manage Prov', 'url'=>array('admin')),
);
?>

<h1>Provs</h1>

<?php $this->widget('zii.widgets.CListView', array(
	'dataProvider'=>$dataProvider,
	'itemView'=>'_view',
)); ?>
