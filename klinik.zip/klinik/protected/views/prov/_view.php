<?php
/* @var $this ProvController */
/* @var $data Prov */
?>

<div class="view">

	<b><?php echo CHtml::encode($data->getAttributeLabel('id_prov')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->id_prov), array('view', 'id'=>$data->id_prov)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('nama_prov')); ?>:</b>
	<?php echo CHtml::encode($data->nama_prov); ?>
	<br />


</div>