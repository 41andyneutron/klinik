<?php
/* @var $this SiteController */

$this->pageTitle=Yii::app()->name;
?>
<?php
if (Yii::app()->session->contains('s_id')) {
    // echo 'Session ditemukan: ' . Yii::app()->session['s_id']. Yii::app()->session['s_nama']. Yii::app()->session['s_level'];
    #tampilkan menu
    switch (Yii::app()->session['s_level']) {
        case '1': #admin
           $menu =['User','Obat','jeniskunjungan','Pasien','Pegawai','Prov','Tindakan','Transaksi','Wilayah'];
            break;
        case '2': #dokter
           $menu =['Transaksi'];
            break;
        case '3': #petugas
           $menu =['Pasien','Obat','Transaksi'];
            break;
        case '4': #kasir
           $menu =['transaksi'];
            break;
        
        default:
            $menu =[];
            break;
    }
    ?><h3>Menu</h3><?php
    foreach ($menu as $key) {
        ?><a href="<?=Yii::app()->request->baseUrl.'/'.strtolower($key);
?>"><button><?=$key;?></button></a> <?php
    }
} else {
    // echo 'Session belum diset.';
	?>Silahkan Login Terlebih Dahulu <a href="<?=Yii::app()->request->baseUrl.'/site/login';
?>"><button>Login</button></a> <?php
}

?>
<!-- <button>test</button> -->