<?php
/* @var $this SiteController */

$this->pageTitle=Yii::app()->name . ' - About';
$this->breadcrumbs=array(
	'About',
);
?>
<h1>About</h1>
User/password: <br>
admin/admin | admin<br>
petugas/petugas | petugas<br>
dokter/dokter | dokter<br>
kasir/kasir | kasir<br>
