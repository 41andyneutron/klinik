<?php
/* @var $this SiteController */
/* @var $model LoginForm */
/* @var $form CActiveForm  */

$this->pageTitle=Yii::app()->name . ' - Login';
$this->breadcrumbs=array(
	'Login',
);
?>

<div class="form">
<form method="post" action="<?=Yii::app()->request->baseUrl;?>/auth/cek_login">
	Username :
	<input type="text" name="username" required><br>
	Password :
	<input type="password" name="password" required><br>
	<button type="submit">Login</button>
</form>

</div><!-- form -->
