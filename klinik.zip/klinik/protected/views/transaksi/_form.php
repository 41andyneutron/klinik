<?php
/* @var $this TransaksiController */
/* @var $model Transaksi */
/* @var $form CActiveForm */
?>

<div class="form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'id'=>'transaksi-form',
	// Please note: When you enable ajax validation, make sure the corresponding
	// controller action is handling ajax validation correctly.
	// There is a call to performAjaxValidation() commented in generated controller code.
	// See class documentation of CActiveForm for details on this.
	'enableAjaxValidation'=>false,
)); ?>

	<p class="note">Fields with <span class="required">*</span> are required.</p>

	<?php echo $form->errorSummary($model); ?>

	<div class="row">
		<?php echo $form->labelEx($model,'nik'); ?>
		<?php echo $form->textField($model,'nik',array('size'=>16,'maxlength'=>16)); ?>
		<?php echo $form->error($model,'nik'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'id_user_dokter'); ?>
		<?php echo $form->textField($model,'id_user_dokter'); ?>
		<?php echo $form->error($model,'id_user_dokter'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'id_jenis_kunjungan'); ?>
		<?php echo $form->textField($model,'id_jenis_kunjungan'); ?>
		<?php echo $form->error($model,'id_jenis_kunjungan'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'id_obat_array'); ?>
		<?php echo $form->textField($model,'id_obat_array',array('size'=>60,'maxlength'=>500)); ?>
		<?php echo $form->error($model,'id_obat_array'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'biaya'); ?>
		<?php echo $form->textField($model,'biaya'); ?>
		<?php echo $form->error($model,'biaya'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'deskripsi'); ?>
		<?php echo $form->textArea($model,'deskripsi',array('rows'=>6, 'cols'=>50)); ?>
		<?php echo $form->error($model,'deskripsi'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'status'); ?>
		<?php echo $form->textField($model,'status',array('size'=>1,'maxlength'=>1)); ?>
		<?php echo $form->error($model,'status'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'tanggal'); ?>
		<?php echo $form->textField($model,'tanggal'); ?>
		<?php echo $form->error($model,'tanggal'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'id_user_kasir'); ?>
		<?php echo $form->textField($model,'id_user_kasir'); ?>
		<?php echo $form->error($model,'id_user_kasir'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'id_user_petugas'); ?>
		<?php echo $form->textField($model,'id_user_petugas'); ?>
		<?php echo $form->error($model,'id_user_petugas'); ?>
	</div>

	<div class="row buttons">
		<?php echo CHtml::submitButton($model->isNewRecord ? 'Create' : 'Save'); ?>
	</div>

<?php $this->endWidget(); ?>

</div><!-- form -->