<?php
/* @var $this TransaksiController */
/* @var $dataProvider CActiveDataProvider */

$this->breadcrumbs=array(
	'Transaksi',
);

$this->menu=array(
	array('label'=>'Create Transaksi', 'url'=>array('create')),
	array('label'=>'Manage Transaksi', 'url'=>array('admin')),
);
?>

<h1>Transaksi</h1>
<?php
if (Yii::app()->session['s_level']!=3) {
if (Yii::app()->session['s_level']==4) {
		$text = 'Cek Tagihan ';
	}	else {
		$text = 'Penanganan';
	}
?>
<p>
Untuk <?=$text;?> Pasien Silahkan Input NIK Pasien.
<?php echo CHtml::beginForm(array('transaksi/kelola'), 'get'); ?>

    <?php echo CHtml::label('NIK', 'nik'); ?>
    <?php echo CHtml::textField('nik'); ?>

    <?php echo CHtml::submitButton('Cek'); ?>

<?php echo CHtml::endForm(); ?></p>
<?php } ?>
<?php $this->widget('zii.widgets.CListView', array(
	'dataProvider'=>$dataProvider,
	'itemView'=>'_view',
)); ?>