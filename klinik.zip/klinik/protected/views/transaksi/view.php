<?php
/**
* Class and Function List:
* Function list:
* Classes list:
*/
/* @var $this TransaksiController */
/* @var $model Transaksi */

$this->breadcrumbs = array(
    'Transaksis' => array(
        'index'
    ) ,
    $model->id_transaksi,
);

$this->menu = array(
    array(
        'label' => 'List Transaksi',
        'url' => array(
            'index'
        )
    ) ,
    array(
        'label' => 'Create Transaksi',
        'url' => array(
            'create'
        )
    ) ,
    array(
        'label' => 'Update Transaksi',
        'url' => array(
            'update',
            'id' => $model->id_transaksi
        )
    ) ,
    array(
        'label' => 'Delete Transaksi',
        'url' => '#',
        'linkOptions' => array(
            'submit' => array(
                'delete',
                'id' => $model->id_transaksi
            ) ,
            'confirm' => 'Are you sure you want to delete this item?'
        )
    ) ,
    array(
        'label' => 'Manage Transaksi',
        'url' => array(
            'admin'
        )
    ) ,
);
?>

<h1>View Transaksi #<?php echo $model->id_transaksi; ?></h1>

<?php $this->widget('zii.widgets.CDetailView', array(
    'data' => $model,
    'attributes' => array(
        'id_transaksi',
        array(
            'label' => 'Nama Pasien',
            'value' => Pasien::model()->findByAttributes(array(
                'nik' => $model->nik
            ))->nama_pasien,
        ) ,

        array(
            'label' => 'Nama Dokter',
            'value' => isset($model->dokter) ? $model->dokter->nama_user : 'Tidak ditemukan',
        ) ,
        array(
            'label' => 'Jenis Kunjungan',
            'value' => isset($model->jenisKunjungan) ? $model->jenisKunjungan->nama_kunjungan : 'Tidak ditemukan',
        ) ,
        array(
            'label' => 'Tindakan',
            'value' => isset($model->tindakan) ? $model->tindakan->nama_tindakan : 'Tidak ditemukan',
        ) ,
        'id_obat_array',
        'biaya',
        'deskripsi',
        'status',
        'tanggal',
        'id_user_kasir',
        array(
            'label' => 'Nama Petugas',
            'value' => isset($model->petugas) ? $model->petugas->nama_user : 'Tidak ditemukan',
        ) ,
    ) ,
)); ?>
<?php
if (Yii::app()->session['s_level']==2) {
?>
<h3>Kelola Data Ini</h3>
<?php echo CHtml::beginForm(array('transaksi/update2/id/'.$model->id_transaksi), 'post'); ?>
<label>Pilih Tindakan</label>
<select name="Transaksi[id_tindakan]" required>
    <option value="">Pilih</option>
    <?php
foreach ($list_tindakan as $key) {
    ?><option value="<?=$key['id_tindakan'];?>"><?=$key['nama_tindakan'];?></option> <?php
}
?>
</select><br>
<label>Obat</label>
<select name="Transaksi[id_obat]">
    <option value="">Tidak Ada</option>
    <?php
foreach ($list_obat as $key2) {
    ?><option value="<?=$key2['id_obat'];?>"><?=$key2['nama_obat'];?></option> <?php
}
?>
</select><br>

    <?php echo CHtml::submitButton('Submit'); ?>

<?php echo CHtml::endForm(); ?>
<?php
}
?>

<?php
if (Yii::app()->session['s_level']==4) {
if ($status=='N') {
   
?>
<h3>Pembayaran</h3>
<?php echo CHtml::beginForm(array('transaksi/bayar/id/'.$model->id_transaksi), 'post'); ?>
Jumlah Tagihan : Rp<?=$total;?>,00<br>
Jumlah Bayar : <input type="number" name="Transaksi[bayar]" value="<?=$total;?>"><br>
    <?php echo CHtml::submitButton('Bayar'); ?>

<?php echo CHtml::endForm(); ?>
<?php
 // code...
} else {
    echo 'Sudah Bayar';
}
}
?>
