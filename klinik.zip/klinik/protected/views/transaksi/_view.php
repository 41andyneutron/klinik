<?php
/* @var $this TransaksiController */
/* @var $data Transaksi */
?>

<div class="view">

	<b><?php echo CHtml::encode($data->getAttributeLabel('id_transaksi')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->id_transaksi), array('view', 'id'=>$data->id_transaksi)); ?>
	<br />

	<b>NIK:</b>
	<?php echo CHtml::encode($data->nik); ?>
	<br />

	<b>Nama Pasien:</b> 
	<?php 
		echo isset($data->pasien) 
			? CHtml::encode($data->pasien->nama_pasien) 
			: 'Tidak ditemukan'; 
	?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('Nama Dokter')); ?>:</b>
    <?php echo isset($data->dokter) ? CHtml::encode($data->dokter->nama_user) : 'Tidak ditemukan'; ?>
    <br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('Jenis Kunjungan')); ?>:</b>
    <?php echo isset($data->jenisKunjungan) ? CHtml::encode($data->jenisKunjungan->nama_kunjungan) : 'Tidak ditemukan'; ?>
    <br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('id_obat_array')); ?>:</b>
	<?php echo CHtml::encode($data->id_obat_array); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('biaya')); ?>:</b>
	<?php echo CHtml::encode($data->biaya); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('deskripsi')); ?>:</b>
	<?php echo CHtml::encode($data->deskripsi); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('status')); ?>:</b>
	<?php echo CHtml::encode($data->status); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('tanggal')); ?>:</b>
	<?php echo CHtml::encode($data->tanggal); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('id_user_kasir')); ?>:</b>
	<?php echo CHtml::encode($data->id_user_kasir); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('id_user_petugas')); ?>:</b>
	<?php echo CHtml::encode($data->id_user_petugas); ?>
	<br />


</div>