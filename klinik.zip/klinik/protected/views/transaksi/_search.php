<?php
/* @var $this TransaksiController */
/* @var $model Transaksi */
/* @var $form CActiveForm */
?>

<div class="wide form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'action'=>Yii::app()->createUrl($this->route),
	'method'=>'get',
)); ?>

	<div class="row">
		<?php echo $form->label($model,'id_transaksi'); ?>
		<?php echo $form->textField($model,'id_transaksi'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'nik'); ?>
		<?php echo $form->textField($model,'nik',array('size'=>16,'maxlength'=>16)); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'id_user_dokter'); ?>
		<?php echo $form->textField($model,'id_user_dokter'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'id_jenis_kunjungan'); ?>
		<?php echo $form->textField($model,'id_jenis_kunjungan'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'id_obat_array'); ?>
		<?php echo $form->textField($model,'id_obat_array',array('size'=>60,'maxlength'=>500)); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'biaya'); ?>
		<?php echo $form->textField($model,'biaya'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'deskripsi'); ?>
		<?php echo $form->textArea($model,'deskripsi',array('rows'=>6, 'cols'=>50)); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'status'); ?>
		<?php echo $form->textField($model,'status',array('size'=>1,'maxlength'=>1)); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'tanggal'); ?>
		<?php echo $form->textField($model,'tanggal'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'id_user_kasir'); ?>
		<?php echo $form->textField($model,'id_user_kasir'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'id_user_petugas'); ?>
		<?php echo $form->textField($model,'id_user_petugas'); ?>
	</div>

	<div class="row buttons">
		<?php echo CHtml::submitButton('Search'); ?>
	</div>

<?php $this->endWidget(); ?>

</div><!-- search-form -->